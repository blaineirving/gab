let theLocale;

export function setLocale(locale) {
  theLocale = locale;
}

export function getLocale() {
  return theLocale;
}

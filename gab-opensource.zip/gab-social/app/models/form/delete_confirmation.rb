# frozen_string_literal: true

class Form::DeleteConfirmation
  include ActiveModel::Model

  attr_accessor :password
end
